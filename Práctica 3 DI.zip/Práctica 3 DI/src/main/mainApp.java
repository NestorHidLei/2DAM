package main;

import swing.Login;

public class mainApp {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		Login lg = new Login();
		lg.setVisible(true);
	}

}
