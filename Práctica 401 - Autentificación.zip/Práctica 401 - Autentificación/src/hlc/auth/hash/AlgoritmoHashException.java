package hlc.auth.hash;

public class AlgoritmoHashException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public AlgoritmoHashException(String message, Throwable cause) {
    super(message, cause);
  }

}
