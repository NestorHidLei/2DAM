package hlc.auth.otp;

public class GeneradorException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public GeneradorException(String message, Throwable cause) {
    super(message, cause);
  }

}
